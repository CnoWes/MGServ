# MGS Admin для Windows

Десктопное приложение на Tauri 2 открывает веб-панель MGS Admin в отдельном окне.

## Адрес панели

Адрес задаётся в `src-tauri/tauri.conf.json` в поле `app.windows[0].url`:

```json
"url": "http://192.168.88.17:8080"
```

После изменения адреса приложение необходимо пересобрать.

## Разработка

Требуются Node.js, Rust и Microsoft C++ Build Tools.

```powershell
npm install
npm run tauri dev
```

## Сборка Windows

### Через GitHub Actions — рекомендуется

На локальный компьютер ничего устанавливать не требуется.

1. Откройте репозиторий на GitHub.
2. Перейдите в раздел `Actions`.
3. Выберите «Сборка MGS Admin для Windows».
4. Нажмите `Run workflow`.
5. При необходимости измените адрес панели и запустите сборку.
6. После завершения скачайте артефакт `MGS-Admin-Windows-x64`.

В архиве будут:

- `MGS-Admin-portable.exe` — переносимая версия;
- NSIS `.exe` — обычный установщик;
- `.msi` — установщик Windows Installer.

Workflow также запускается автоматически при изменениях в папке `winexe`.

### Локальная сборка

```powershell
npm run tauri build
```

Готовые файлы создаются в `src-tauri/target/release/bundle`. Обычный исполняемый файл находится в `src-tauri/target/release/mgs-admin.exe`.

Приложение не предоставляет загруженной странице доступ к Tauri API и локальным системным командам.
